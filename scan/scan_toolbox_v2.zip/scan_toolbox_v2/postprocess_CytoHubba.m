function [Output] = postprocess_CytoHubba(fileName1,fileName2)
% Reads an output of the CytoHubba and construct a new output file which has been added the name of the related SBML metabolites or reactions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The "PostProcess" Functions in this toolbox do some changes on some useful structural plugins in the Cytoscape software.
% This function reads an output (.csv format) of the CytoHubba (a Cytoscape plugin),
% and construct a new output file which has been added the name of the related SBML metabolites or reactions.
% http://hub.iis.sinica.edu.tw/cytoHubba/
% Note: COBRA Toolbox must be installed in MATLAB before running this function
% Note: This function is applicable for CytoHubba analysis on Bipartite, Metabolite-Metabolite, and Enzyme-Enzyme networks (both Directed and Undirected).
%
% [Output] = postprocess_CytoHubba(fileName1,fileName2)
%
%INPUTS
% fileName1                        comma separated file includes CytoHubba results for a given ranking method (in .csv format)
% fileName2                        The metabolic Network in the SBML format
% 
%OUTPUTS
% *_fileName1_fileName2.dat        The output file which includes the name of the related SBML metabolites or reactions.
% 
% Yazdan Asgari 07/16/2016         http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input files format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check1=regexp(fileName1,'.csv');
assert(~isempty(check1),'Error in the first input: The fileName1 must contain .csv at its end')
check2=regexp(fileName2,'.xml');
assert(~isempty(check2),'Error in the second input: The fileName2 must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName1,'.xml','');
outname2=strrep(fileName2,'.csv','.dat');
outname3=strcat(outname1,outname2)
fout = fopen(outname3, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading an output (.csv format) of the CytoHubba and ignore first and second lines.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen(fileName1);
fgetl(fid);
fgetl(fid);
M=textscan(fid,'%*d %s %*d','delimiter', ',');
C=M{1};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construct a new output file which has been added the name of the related SBML metabolites or reactions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[g,h]=size(C);
[k,n]=size(model.mets);
[kk,nn]=size(model.rxns);
for i=1:g
    p=0;
    if strncmp(C(i,1),'E_',2)==1
        fprintf(fout,'%s\n ',C{i});
        p=p+1;
    end
    if p==0
        for j=1:k
            Maddition=strcat('M_',model.mets{j});
            if strcmp(C(i,1),Maddition)==1
                fprintf(fout,'%s\t%s\n ',model.mets{j},model.metNames{j});
                p=p+1;
                break;
            end
        end
    end
    if p==0
        for j=1:kk
            Raddition=strcat('R_',model.rxns{j});
            if strcmp(C(i,1),Raddition)==1
                fprintf(fout,'%s\t%s\n ',model.rxns{j},model.rxnNames{j});
                p=p+1;
                break;
            end
        end
    end
    if p==0
        fprintf(fout,'%s\n ',C{i});
    end
end
fclose(fid);
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;

