function [Output] = enz_cent_RCM_dir_kavosh(fileName)
% Builds Directed Enzyme-Enzyme Networks Removing Currency Metabolites which could be used as an input for Kavosh Algorithm.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file, 
% and builds Directed Enzyme-Enzyme Networks which is compatible with Kavosh Algorithm.
% The Kavosh is one of the best motif finding algorithms. Its Cytoscape plugins is also called CytoKavosh.
% http://lbb.ut.ac.ir/Download/LBBsoft/Kavosh/  &   http://www.ncbi.nlm.nih.gov/pubmed/19799800
% http://lbb.ut.ac.ir/Download/LBBsoft/CytoKavosh/CytoKavosh-Manual/cytoKavoshTutorial.html
% So, one could easily use this algorithm in order to find motifs in different sizes for the metabolic network.
% The Remove Currency Metabolites (RCM) algorithm removes currency metabolites in the metabolic network automatically.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = enz_cent_RCM_dir_kavosh(fileName)
%
%INPUTS
% fileName                             The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Enzyme_Cent_RCM_Dir_Index.dat      Matrix Indeces of Enzyme-Enzyme Connections 
% *_Enzyme_Cent_RCM_Dir_Kavosh.dat     Directed-Enzyme-Enzyme Network - Kavosh Compatible
% 
% Yazdan Asgari 07/16/2016          http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command, and sets size of the S matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate summation of each columns (i.e. How many metabolites each enzyme correlates)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;
CB=sum(S_bin,1);
A=zeros(m,n);
B=zeros(m,1);
N3=zeros(m,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for each binary S-matrix element, subtracts its value from the column summation and put the result in the A matrix. 
% A(q) means the metabolite q connects to how many other metabolites through the enzyme i.
% for each row, sums the binary S-matrix over all columns.
% B(q) means how many enzymes the metabolite q correlates. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    for i=1:n
        if S_bin(q,i)~=0
            A(q,i)=CB(1,i)-S_bin(q,i);
        end
        B(q,1)=B(q,1)+S_bin(q,i);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assumption: Generally, every metabolite is connected to the other one through a specific enzyme.
% If a metabolite connects to more than one metabolite through an enzyme, this will be considered as a suspicious case.
% Therefore, every A(q) value equal to 3 will be marked for further analysis.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    for i=1:n
        if A(q,i)==3
            N3(q,1)=N3(q,1)+1;
        end
    end
end

s=0;
for q=1:m
    if N3(q,1)~=0
        s=1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If there is any value for N3 array, the RCM algorithm will be done.
% This algorithm will be deleted the most probable metabolite among all (i.e. the one with the maximum value of N3 and C)
% The selected metabolite will be deleted in the binary S-Matrix, and the "WHILE LOOP" repeated.
% The algorithm is ended if there is not any suspicious case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
while s==1
    C=zeros(m,1);
    max1=max(N3,[],1);
    for q=1:m
        if N3(q,1)==max1
            C(q,1)=B(q,1);
        else
            C(q,1)=0;
        end
    end
    max2=max(C,[],1);
    for q=1:m
        if ( (N3(q,1)==max1) && (C(q,1)==max2) )
            for i=1:n
                S_bin(q,i)=0;
                model.S(q,i)=0;
            end
        end
    end    
    CB=sum(S_bin,1);
    A=zeros(m,n);
    B=zeros(m,1);
    N3=zeros(m,1);
    for q=1:m
        for i=1:n
            if S_bin(q,i)~=0
                A(q,i)=CB(1,i)-S_bin(q,i);
            end
            B(q,1)=B(q,1)+S_bin(q,i);
        end
    end
    for q=1:m
        for i=1:n
            if A(q,i)==3
                N3(q,1)=N3(q,1)+1;
            end
        end
    end
    s=0;
    for q=1:m
        if N3(q,1)~=0
            s=1;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName,'.xml','_Enzyme_Cent_RCM_Dir_Index.dat')
fout1 = fopen(outname1, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% finds non-zero elements of the S-matrix (in order to make the algorithm faster), 
% parses through each row, and considers an edge for every unlike-signs.
% It also consider Reversibility for Enzyme-Enzyme network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num=zeros(size(model.rxns));
for j=1:m
    indices=find(model.S(j,:));
    [a,b]=size(indices);
    r=0;
    if b~=0
        r=1;
    end
    while r<b
        i=1;
        while i<(b-r+1)
            if model.S(j,indices(1,r))>0 && model.S(j,indices(1,r+i))<0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1
                    fprintf(fout1,'%d\t%d\n',indices(1,r),indices(1,r+i));
                    fprintf(fout1,'%d\t%d\n',indices(1,r+i),indices(1,r));
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout1,'%d\t%d\n',indices(1,r),indices(1,r+i));
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            elseif model.S(j,indices(1,r))<0 && model.S(j,indices(1,r+i))>0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1
                    fprintf(fout1,'%d\t%d\n',indices(1,r+i),indices(1,r));
                    fprintf(fout1,'%d\t%d\n',indices(1,r),indices(1,r+i));
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout1,'%d\t%d\n',indices(1,r+i),indices(1,r));
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            end
            i=i+1;
        end
        r=r+1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname2=strrep(fileName,'.xml','_Enzyme_Cent_RCM_Dir_Kavosh.dat')    
fout2=fopen(outname2,'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the constructed Enzyme-Enzyme network file and re-format it to a Kavosh-compatible file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen(outname1);
C=fscanf(fid,'%d');
i=1;
while isinteger(fid)
    C(i)=fscanf(fid,'%d',C);
    i=i+1;
end
g=size(C);
A=size(unique(C));
if g~=0
    n=1;
else
    disp('Error in reading the file, No Edge detected')
end
k=1;
j=2;
last=g/2;
fprintf(fout2,'%d\n',A(1,1));   % total number of uniques nodes in the network (needed for Kavosh Algorithm)
for i=1:last
    fprintf(fout2,'%d\t%d\n ',C(k),C(j));
    k=k+2;
    j=j+2;
end
fclose(fid);
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
