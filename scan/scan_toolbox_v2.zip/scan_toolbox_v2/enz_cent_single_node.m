function [Output] = enz_cent_single_node(fileName)
% Builds Binary Stoichiometric Matrix and Undirected Enzyme-Enzyme Networks considering Currency Metabolites and single nodes (without any edges)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file and builds Stoichiometric Matrix,
% Binary Stoichiometric Matrix, and Enzyme-Enzyme Networks.
% This file also contains single nodes (without any edges) in Cytoscape-compatible files.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
% Note: Currency metabolites have been considered for construction of this network. 
%
% [Output] = enz_cent_single_node(fileName)
%
%INPUTS
% fileName                                 The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Stoich_Matrix.dat                      Stoichiometric Matrix (comma separated Format)
% *_Binary_Stoich_Matrix.dat               Binary Stoichiometric Matrix (comma separated Format)
% *_Enzyme_Cent.dat                        Undirected-Enzyme-Enzyme Network (comma separated Format)
% *_Enzyme_Cent_single_node_Cyt.dat        Undirected-Enzyme-Enzyme Network - Cytoscape Compatible (contains single nodes (without any edges))
% 
% Yazdan Asgari 07/16/2016                 http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Stoichiometric Matrix (comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName,'.xml','_Stoich_Matrix.dat')
dlmwrite(outname1,full(model.S));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Binary Stoichiometric Matrix (comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;
outname2=strrep(fileName,'.xml','_Binary_Stoich_Matrix.dat')
dlmwrite(outname2,full(S_bin));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Undirected-Enzyme-Enzyme Network (comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Aenz=S_bin'*S_bin;
outname3=strrep(fileName,'.xml','_Enzyme_Cent.dat')
dlmwrite(outname3,full(Aenz));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading a Enzyme-Enzyme comma separated file and re-format it 
% to a Cytoscape-compatible file.
% One could import the file using "File/Import/Network from Table(Text/MS Excel)..."
% Select "first column" as "Source Interaction" and "second column" as "Target Interaction"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ss = csvread(outname3);
[g,h]=size(ss);
outname4=strrep(fileName,'.xml','_Enzyme_Cent_single_node_Cyt.dat')
fout = fopen(outname4, 'w+');
for row=1:g
    num=0;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % because cell(i,j)=cell(j,i) we must delete duplicate entries by putting
    % col=row:h in the second if command. since we must ignor diagonal elements,
    % the counter will be col=row+1:h
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for col=row+1:h
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % edge are those which includes number not equal to zero
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if ss(row,col)~=0
            fprintf(fout,'%s\t%s\t%d\n',model.rxns{row},model.rxns{col},ss(row,col));
            num=num+1;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % considering nodes which do not contain any edges
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if num==0
        fprintf(fout,'%s\n',model.rxns{row});
    end
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
