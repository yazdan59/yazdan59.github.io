function [Output] = postprocess_MCODE(fileName1,fileName2)
% Reads an output of the MCODE and construct a new output file which has been added the name of the related SBML metabolites or reactions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The "PostProcess" Functions in this toolbox do some changes on some useful structural plugins in the Cytoscape software.
% This function reads an output of the MCODE (a Cytoscape plugin),
% and construct a new output file which has been added the name of the related SBML metabolites or reactions.
% http://baderlab.org/Software/MCODE
% Note: COBRA Toolbox must be installed in MATLAB before running this function
% Note: This function is applicable for MCODE analysis on Bipartite, Metabolite-Metabolite, and Enzyme-Enzyme networks (both Directed and Undirected).
%
% [Output] = postprocess_MCODE(fileName1,fileName2)
%
%INPUTS
% fileName1                                  text file includes MCODE results for network clustering
% fileName2                                  The metabolic Network in the SBML format
% 
%OUTPUTS
% *_fileName_fileName2_MCODE_clusters.dat    The output file which includes the name of the related SBML metabolites or reactions.
% *_fileName_fileName2_MCODE.dat             This output file saves some data which will be used for the main output file in this program 
% 
% Yazdan Asgari 07/16/2016                   http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input files format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName2,'.xml');
assert(~isempty(check),'Error in the second input: The fileName2 must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading an output of the MCODE and write first 10 lines to the new output file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen(fileName1);
outname1=strrep(fileName2,'.xml','_');
outname2=strcat(outname1,fileName1);
outname3=strcat(outname2,'_MCODE_clusters.dat')
fout = fopen(outname3, 'w+');
B={};
for i=1:10
    B{i}=fgetl(fid);
    fprintf(fout,'%s\n',B{i});
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the rest of the MCODE output file and construct a new output file,
% which has been added the name of the related SBML metabolites or reactions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i=1;
A={};
line={};
while ~feof(fid)
    A{i} = fscanf(fid,'%d %f %d %d');
    line{i} = fgetl(fid);
    i=i+1;
end

M={};
for j=1:i-1
    M{1,j}=regexp(line{1,j},',','split');
end
fclose(fid);

outname4=strrep(fileName2,'.xml','_');
outname5=strcat(outname4,fileName1);
outname6=strcat(outname5,'_MCODE.dat')
fout2 = fopen(outname6, 'w+');
[h,hh]=size(model.mets);
[r,rr]=size(model.rxns);
for k=1:i-1
    k;
    [ee,e]=size(M{1,k});
    g=1;
    while g<e+1
        M{1,k}{1,g};
        if g==1
            p=0;
            if strncmp(M{1,k}{1,g},'E_',2)==1
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
                p=p+1;
            end
            if p==0
                for jj=1:r
                    Raddition=strcat('R_',model.rxns{jj});
                    if strcmp(M{1,k}{1,g},Raddition)==1
                        fprintf(fout2,'%s\t\t',model.rxnNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                for jj=1:h
                    Maddition=strcat('M_',model.mets{jj});
                    if strcmp(M{1,k}{1,g},Maddition)==1
                        fprintf(fout2,'%s\t\t',model.metNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
            end
            g=g+1;
        elseif g~=1
            p=0;
            if strncmp(M{1,k}{1,g},' E_',2)==1
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
                p=p+1;
            end
            if p==0
                for jj=1:r
                    Raddition=strcat(' R_',model.rxns{jj});
                    if strcmp(M{1,k}{1,g},Raddition)==1
                        fprintf(fout2,'%s\t\t',model.rxnNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                for jj=1:h
                    Maddition=strcat(' M_',model.mets{jj});
                    if strcmp(M{1,k}{1,g},Maddition)==1
                        fprintf(fout2,'%s\t\t',model.metNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
            end
            g=g+1;
        end
    end
    fprintf(fout2,'\n');
end
fclose(fout2);

fid2 = fopen(outname6);
y=1;
while ~feof(fid2)
    E{y}=fgetl(fid2);
    y=y+1;
end
fclose(fid2);

for i=1:i-1
    C=A{1,i};
    fprintf(fout,'%d\t%f\t%d\t%d\t%s\n',C(1),C(2),C(3),C(4),line{1,i});
    fprintf(fout,'%s\n\n',E{i});
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
