function [Output] = postprocess_CytoHubba_list(Path1,Path2,N)
% Reads a list of CytoHubba outputs and construct new outputs which have been added the name of the related SBML metabolites or reactions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The "PostProcess" Functions in this toolbox do some changes on some useful structural plugins in the Cytoscape software.
% This function reads different files (in .csv format) which all are CytoHubba (a Cytoscape plugin) outputs (each related to a given ranking method)
% and construct new output files include the name of the related SBML metabolites or reactions.
% http://hub.iis.sinica.edu.tw/cytoHubba/
% Note: COBRA Toolbox must be installed in MATLAB before running this function
% Note: This function is applicable for CytoHubba analysis on Bipartite, Metabolite-Metabolite, and Enzyme-Enzyme networks (both Directed and Undirected).
% 
% [Output] = postprocess_CytoHubba_list(fileName1,fileName2)
%
%INPUTS
% Path1                        comma separated files include CytoHubba results for different ranking method (in .csv format)
% Path2                        Paths in which the metabolic Networks in the SBML format exist
% N                            Number of .csv files per each .xml file.
% Note: N must be equal for all SBML files (i.e. the algorithm is repeated N times for each SBML files). So, N is related to number of .csv files for each SBML file.
% Note: This function is applicable for CytoHubba analysis on Bipartite, Metabolite-Metabolite, and Enzyme-Enzyme networks.
% 
%OUTPUTS
% *_fileName1_fileName2.dat    The output files which include the name of the related SBML metabolites or reactions.
% 
% Yazdan Asgari 07/16/2016     http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input files format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
assert(~isnumeric(N),'Error in the third input: The N must be an integer number')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of whole program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reading all CytoHubba results files (.csv format) in the Path1 directory ,
% and reading the SBML files (.xml format) in the Path2 directory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
allcsvfiles=dir(fullfile(Path1,'*.csv'));
[a,b]=size(allcsvfiles);
sbmlfiles=dir(fullfile(Path2,'*.xml'));
[c,d]=size(sbmlfiles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Doing algorithm for all CytoHubba files one by one
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t=1;
s=1;
for r=1:a
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % start time evaluation of each .csv algorithm process 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    tic;
    D=allcsvfiles(r).name;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % check to change SBML file every Nth times
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if t==1
        model=readCbModel(sbmlfiles(s).name)
        sbmlfiles(s).name;
        s=s+1;
    end
    if t==N
        t=0;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % building the output file name
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    outname1=strrep(sbmlfiles(s-1).name,'.xml','');
    outname2=strrep(D,'.csv','.dat');
    outname3=strcat(outname1,outname2);
    fout=fopen(outname3,'w+');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % reading an output (.csv format) of the CytoHubba and ignore first and second lines.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fid = fopen(allcsvfiles(r).name)
    fgetl(fid);
    fgetl(fid);
    M=textscan(fid,'%*d %s %*d','delimiter', ',');
    C=M{1};
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % construct a new output file which has been added the name of the related SBML metabolites or reactions.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [g,h]=size(C);
    [k,n]=size(model.mets);
    [kk,nn]=size(model.rxns);
    for i=1:g
        p=0;
        if strncmp(C(i,1),'E_',2)==1
            fprintf(fout,'%s\n ',C{i});
            p=p+1;
        end
        if p==0
            for j=1:k
                Maddition=strcat('M_',model.mets{j});
                if strcmp(C(i,1),Maddition)==1
                    fprintf(fout,'%s\t%s\n ',model.mets{j},model.metNames{j});
                    p=p+1;
                    break;
                end
            end
        end
        if p==0
            for j=1:kk
                Raddition=strcat('R_',model.rxns{j});
                if strcmp(C(i,1),Raddition)==1
                    fprintf(fout,'%s\t%s\n ',model.rxns{j},model.rxnNames{j});
                    p=p+1;
                    break;
                end
            end
        end
        if p==0
            fprintf(fout,'%s\n ',C{i});
        end
    end
    fclose(fid);
    fclose(fout);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % End of time evaluation of each .csv algorithm process 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    toc;
    
    t=t+1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of whole program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;

