function [Output] = met_dist(fileName)
% Counts total occurance of each metabolite through the network and total number of metabolites per reaction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file, 
% counts total occurance of each metabolite through the network,
% and total number of metabolites per reaction
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = met_dist(fileName)
%
%INPUTS
% fileName                        The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Met_Distribution.dat          total occurance of each metabolite through the network
% *_Rxn_Participation.dat         total number of metabolites per reaction
% 
% Yazdan Asgari 07/16/2016        http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% preparation to calculate total occurance of each metabolite through the network,
% and write them to the output files
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname2=strrep(fileName,'.xml','_Met_Distribution.dat')
fout = fopen(outname2, 'w+');
fprintf(fout, 'Metabolite\t\tTotal Occurance\n');
fprintf(fout, '----------------------------------------------\n');
j=0;
for row=1:m
    i=0;
    for col=1:n
        if model.S(row,col)~=0
            i=i+1;
        end
    end
    fprintf(fout, '%s\t\t%d\n',model.mets{row},i);
    j=j+i;
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculation total number of metabolites per reaction,
% and write them to the output files
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname3=strrep(fileName,'.xml','_Rxn_Participation.dat')
fout2 = fopen(outname3, 'w+');
fprintf(fout, 'Reaction\t\t\tTotal Metabolites per Reaction\n');
fprintf(fout, '------------------------------------------------------------\n');
jj=0;
for col=1:n
    ii=0;
    for row=1:m   
        if model.S(row,col)~=0
            ii=ii+1;
        end
    end
    fprintf(fout2, '%s\t\t%d\n',model.rxns{col},ii);
    jj=jj+ii;
end
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
