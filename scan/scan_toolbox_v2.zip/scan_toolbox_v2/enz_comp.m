function [Output] = enz_comp(fileName1,fileName2)
% reads two Metabolic Network SBML files, compares them and finds Enzymes which are not in common
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads two Metabolic Network SBML files,
% compares them and finds Enzymes which are not in common among these models.
% Then, write the differences in output files.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = enz_comp(fileName1,fileName2)
%
%INPUTS
% fileName1                                The first metabolic Network in the SBML format
% fileName2                                The second metabolic Network in the SBML format
% 
%OUTPUTS
% *_rxns_filename1_not_in_filename2.dat    Enzymes in the first SBML file which do not exist in the second SBML file
% *_rxns_filename2_not_in_filename1.dat    Enzymes in the second SBML file which do not exist in the first SBML file
% 
% Yazdan Asgari 07/16/2016                 http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check1=regexp(fileName1,'.xml');
assert(~isempty(check1),'Error in the first input: The fileName1 must contain .xml at its end')
check2=regexp(fileName2,'.xml');
assert(~isempty(check2),'Error in the second input: The fileName2 must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML files using COBRA Toolbox Command and calculate size of them
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model1=readCbModel(fileName1);
model2=readCbModel(fileName2);
[m,mm]=size(model1.rxnNames);
[n,nn]=size(model2.rxnNames);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName1,'.xml','');
outname2=strrep(fileName2,'.xml','.dat');
outname3=strcat('Rxns_in_',outname1);
outname4=strcat(outname3,'_not_in_');
outname5=strcat(outname4,outname2);
fout = fopen(outname5, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compares two files and finds Enzymes in the first file which are not in the second one
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:m
    a=0;
    for j=1:n
        if strcmp(model1.rxnNames{i},model2.rxnNames{j})==1
            a=a+1;
        end
    end
    if a==0
        fprintf(fout,'%s\t\t%s\n',model1.rxns{i},model1.rxnNames{i});
    end
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname6=strrep(fileName2,'.xml','');
outname7=strrep(fileName1,'.xml','.dat');
outname8=strcat('Rxns_in_',outname6);
outname9=strcat(outname8,'_not_in_');
outname10=strcat(outname9,outname7);
fout2 = fopen(outname10, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compares two files and finds Enzymes in the second file which are not in the first one
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:n
    b=0;
    for i=1:m
        if strcmp(model2.rxnNames{j},model1.rxnNames{i})==1
            b=b+1;
        end
    end
    if b==0
        fprintf(fout2,'%s\t\t%s\n',model2.rxns{j},model2.rxnNames{j});
    end
end
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc
