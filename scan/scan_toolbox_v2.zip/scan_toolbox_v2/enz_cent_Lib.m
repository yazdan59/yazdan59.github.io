function [Output] = enz_cent_Lib(fileName1,fileName2)
% Builds Undirected Enzyme-Enzyme Network with Removing Currency Metabolites (based-on a Library file)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file and builds an Undirected Enzyme-Enzyme Network.
% For every metabolite, the algorithm checks availability in the Library file which has been prepared by user as input in .txt format).
% and removes if it exists in the library file. Then the Undirected Enzyme-Enzyme Network will be created.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = enz_cent_Lib(fileName1,fileName2)
%
%INPUTS
% fileName1                     The Library file includes pre-defined currency metabolites (in .txt format)
% Note: Library text file must include one metabolites per line (all in one column) 
% fileName2                     The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Removed_Mets_Lib.dat        file contains removed metabolits from the original model
% *_Enzyme_Cent_Lib.dat         Undirected-Enzyme-Enzyme Network (comma separated Format)
% *_Enzyme_Cent_Lib_Cyt.dat     Undirected-Enzyme-Enzyme Network - Cytoscape Compatible
% 
% Yazdan Asgari 07/16/2016         http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input files format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check1=regexp(fileName1,'.txt');
assert(~isempty(check1),'Error in the first input: The fileName1 must contain .txt at its end')
check2=regexp(fileName2,'.xml');
assert(~isempty(check2),'Error in the second input: The fileName2 must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the Library text file and construct array of currency metabolites
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen(fileName1);
tline = fgetl(fid);
i=1;
Curr_met={};
while ischar(tline)
    Curr_met{i,1}=tline;
    tline = fgetl(fid);
    i=i+1;
end
fclose(fid);
[h,g]=size(Curr_met);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command, and sets size of the S matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName2);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the Metabolites array and check their availability in the library text file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N_curr=zeros(m,1);
for q=1:m
    for i=1:h
        if strcmp(model.metNames{q},Curr_met{i,1})==1
            N_curr(q,1)=N_curr(q,1)+1;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name for writing removed metabolites
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName2,'.xml','_Removed_Mets_Lib.dat')
fout1 = fopen(outname1, 'w+');
fprintf(fout1, 'Metabolite\t\tMetabolite Name\n');
fprintf(fout1, '------------------------------\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove metabolites which are in the input Currecny Metabolites list
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    if N_curr(q,1)~=0
        for i=1:n
            model.S(q,i)=0;
        end
        fprintf(fout1,'%s\t\t%s\n',model.mets{q},model.metNames{q});
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Binary Stoichiometric Matrix from the new S-matrix(comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Undirected-Enzyme-Enzyme Network based on the binary S-matrix(comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Aenz=S_bin'*S_bin;
outname2=strrep(fileName2,'.xml','_Enzyme_Cent_Lib.dat')
dlmwrite(outname2,full(Aenz));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% re-format of Undirected-Enzyme-Enzyme Network it to a Cytoscape-compatible file.
% One could import the file using "File/Import/Network from Table(Text/MS Excel)..."
% Select "first column" as "Source Interaction" and "second column" as "Target Interaction"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m,n]=size(Aenz);
outname3=strrep(fileName2,'.xml','_Enzyme_Cent_Lib_Cyt.dat')
fout2 = fopen(outname3, 'w+');
for row=1:m
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % because cell(i,j)=cell(j,i) we must delete duplicate entries by putting
    % col=row:n in the second if command. since we must ignor diagonal elements,
    % the counter will be col=row+1:n
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for col=row+1:n
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % edge are those which includes number not equal to zero
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         if Aenz(row,col)~=0
            fprintf(fout2, '%s\t%s\t%d\n',model.rxns{row},model.rxns{col},Aenz(row,col));            
        end
    end
end
fclose(fout1);
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;

