function [Output] = enz_cent_RCM_dir_single_node(fileName)
% Builds Directed Enzyme-Enzyme Networks Removing Currency Metabolites and considering single nodes (without any edges)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file and builds Directed Enzyme-Enzyme Networks.
% The Remove Currency Metabolites (RCM) algorithm removes currency metabolites in the metabolic network automatically.
% This file contains single nodes (without any edges) in Cytoscape-compatible files.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = enz_cent_RCM_dir_single_node(fileName)
%
%INPUTS
% fileName                                   The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Enzyme_Cent_RCM_Dir_Single_Node_Cyt.sif     Directed-Enzyme-Enzyme Network - Cytoscape Compatible (.sif file)
% 
% Yazdan Asgari 07/16/2016                   http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command, and sets size of the S matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate summation of each columns (i.e. How many metabolites each enzyme correlates)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;
CB=sum(S_bin,1);
A=zeros(m,n);
B=zeros(m,1);
N3=zeros(m,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for each binary S-matrix element, subtracts its value from the column summation and put the result in the A matrix. 
% A(q) means the metabolite q connects to how many other metabolites through the enzyme i.
% for each row, sums the binary S-matrix over all columns.
% B(q) means how many enzymes the metabolite q correlates. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    for i=1:n
        if S_bin(q,i)~=0
            A(q,i)=CB(1,i)-S_bin(q,i);
        end
        B(q,1)=B(q,1)+S_bin(q,i);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assumption: Generally, every metabolite is connected to the other one through a specific enzyme.
% If a metabolite connects to more than one metabolite through an enzyme, this will be considered as a suspicious case.
% Therefore, every A(q) value equal to 3 will be marked for further analysis.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    for i=1:n
        if A(q,i)==3
            N3(q,1)=N3(q,1)+1;
        end
    end
end

s=0;
for q=1:m
    if N3(q,1)~=0
        s=1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If there is any value for N3 array, the RCM algorithm will be done.
% This algorithm will be deleted the most probable metabolite among all (i.e. the one with the maximum value of N3 and C)
% The selected metabolite will be deleted in the binary S-Matrix, and the "WHILE LOOP" repeated.
% The algorithm is ended if there is not any suspicious case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
while s==1
    C=zeros(m,1);
    max1=max(N3,[],1);
    for q=1:m
        if N3(q,1)==max1
            C(q,1)=B(q,1);
        else
            C(q,1)=0;
        end
    end
    max2=max(C,[],1);
    for q=1:m
        if ( (N3(q,1)==max1) && (C(q,1)==max2) )
            for i=1:n
                S_bin(q,i)=0;
                model.S(q,i)=0;
            end
        end
    end    
    CB=sum(S_bin,1);
    A=zeros(m,n);
    B=zeros(m,1);
    N3=zeros(m,1);
    for q=1:m
        for i=1:n
            if S_bin(q,i)~=0
                A(q,i)=CB(1,i)-S_bin(q,i);
            end
            B(q,1)=B(q,1)+S_bin(q,i);
        end
    end
    for q=1:m
        for i=1:n
            if A(q,i)==3
                N3(q,1)=N3(q,1)+1;
            end
        end
    end
    s=0;
    for q=1:m
        if N3(q,1)~=0
            s=1;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name (Cytoscape compatble file)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname=strrep(fileName,'.xml','_Enzyme_Cent_RCM_Dir_Single_Node_Cyt.sif')
fout = fopen(outname, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Directed-Enzyme-Enzyme Network based on the new binary S-matrix
% finds non-zero elements of the new S-matrix (in order to make the algorithm faster), 
% parses through each row, and considers an edge for every unlike-signs.
% It also consider Reversibility for Enzyme-Enzyme network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num=zeros(size(model.rxns));
for j=1:m
    indices=find(model.S(j,:));
    [a,b]=size(indices);
    r=0;
    if b~=0
        r=1;
    end
    while r<b
        i=1;
        while i<(b-r+1)
            if model.S(j,indices(1,r))>0 && model.S(j,indices(1,r+i))<0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            elseif model.S(j,indices(1,r))<0 && model.S(j,indices(1,r+i))>0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            end
            i=i+1;
        end
        r=r+1;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% considering nodes which do not contain any edges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
for k=1:n
    if num(1,k)==0
        fprintf(fout,'%s\n',model.rxns{k});
    end
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
