function [Output] = enz_cent_dir_single_node(fileName)
% Builds Directed Enzyme-Enzyme Networks considering Currency Metabolites and single nodes (without any edges)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file,
% and builds Directed Enzyme-Enzyme Networks.
% This file contains single nodes (without any edges) in Cytoscape-compatible files.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
% Note: Currency metabolites have been considered for construction of this network. 
%
% [Output] = enz_cent_dir_single_node(fileName)
%
%INPUTS
% fileName                                The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Enzyme_Cent_Dir_Single_Node_Cyt.sif   Directed-Enzyme-Enzyme Network - Cytoscape Compatible (.sif file)
% 
% Yazdan Asgari 07/16/2016             http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname=strrep(fileName,'.xml','_Enzyme_Cent_Dir_Single_Node_Cyt.sif')
fout = fopen(outname, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% finds non-zero elements of the S-matrix (in order to make the algorithm faster), 
% parses through each row, and considers an edge for every unlike-signs.
% It also consider Reversibility for Enzyme-Enzyme network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num=zeros(size(model.rxns));
for j=1:m
    indices=find(model.S(j,:));
    [a,b]=size(indices);
    r=0;
    if b~=0
        r=1;
    end 
    while r<b
        i=1;
        while i<(b-r+1)
            if model.S(j,indices(1,r))>0 && model.S(j,indices(1,r+i))<0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1                    
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});                    
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            elseif model.S(j,indices(1,r))<0 && model.S(j,indices(1,r+i))>0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1                    
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});                    
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            end
            i=i+1;
        end
        r=r+1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% considering nodes which do not contain any edges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
for k=1:n
    if num(1,k)==0
        fprintf(fout,'%s\n',model.rxns{k});
    end
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
