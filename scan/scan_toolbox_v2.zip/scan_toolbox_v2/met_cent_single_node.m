function [Output] = met_cent_single_node(fileName)
% Builds Undirected Metabolite-Metabolite Networks considering single nodes (without any edges)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file and builds Stoichiometric Matrix,
% Binary Stoichiometric Matrix, and Metabolite-Metabolite Networks.
% This file also contains single nodes (without any edges) in Cytoscape-compatible files.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = met_cent_single_node(fileName)
%
%INPUTS
% fileName                                 The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Stoich_Matrix.dat                      Stoichiometric Matrix (comma separated Format)
% *_Binary_Stoich_Matrix.dat               Binary Stoichiometric Matrix (comma separated Format)
% *_Metabolite_Cent.dat                    Undirected-Metabolite-Metabolite Network (comma separated Format)
% *_Metabolite_Cent_single_node_Cyt.dat    Undirected-Metabolite-Metabolite Network - Cytoscape Compatible (contains single nodes (without any edges))
% 
% Yazdan Asgari 07/16/2016                 http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Stoichiometric Matrix (comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName,'.xml','_Stoich_Matrix.dat')
dlmwrite(outname1,full(model.S));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Binary Stoichiometric Matrix (comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;
outname2=strrep(fileName,'.xml','_Binary_Stoich_Matrix.dat')
dlmwrite(outname2,full(S_bin));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Undirected-Metabolite-Metabolite Network (comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Acomp=S_bin*S_bin';
outname3=strrep(fileName,'.xml','_Metabolite_Cent.dat')
dlmwrite(outname3,full(Acomp));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading a Metabolic-Metabolic comma separated file and re-format it 
% to a Cytoscape-compatible file.
% One could import the file using "File/Import/Network from Table(Text/MS Excel)..."
% Select "first column" as "Source Interaction" and "second column" as "Target Interaction"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s = csvread(outname3);
[m,n]=size(s);
outname4=strrep(fileName,'.xml','_Metabolite_Cent_single_node_Cyt.dat')
fout = fopen(outname4, 'w+');
for row=1:m
    num=0;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % because cell(i,j)=cell(j,i) we must delete duplicate entries by putting
    % col=row:n in the second if command. since we must ignor diagonal elements,
    % the counter will be col=row+1:n
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for col=row+1:n
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % edge are those which includes number not equal to zero
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if s(row,col)~=0
            fprintf(fout,'%s\t%s\t%d\n',model.mets{row},model.mets{col},s(row,col));
            num=num+1;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % considering nodes which do not contain any edges
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if num==0
        fprintf(fout,'%s\n',model.mets{row});
    end
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
