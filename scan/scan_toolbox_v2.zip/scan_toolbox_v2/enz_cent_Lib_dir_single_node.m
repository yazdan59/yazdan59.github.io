function [Output] = enz_cent_Lib_dir_single_node(fileName1,fileName2)
% Builds Directed Enzyme-Enzyme Network with Removing Currency Metabolites (based-on a Library file) and considering single nodes (without any edges)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file and builds an Directed Enzyme-Enzyme Network.
% For every metabolite, the algorithm checks availability in the Library file which has been prepared by user as input in .txt format).
% and removes if it exists in the library file. Then the Directed Enzyme-Enzyme Network will be created.
% This file also contains single nodes (without any edges) in Cytoscape-compatible files.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = enz_cent_Lib_dir_single_node(fileName1,fileName2)
%
%INPUTS
% fileName1                                   The Library file includes pre-defined currency metabolites (in .txt format)
% Note: Library text file must include one metabolites per line (all in one column) 
% fileName2                                   The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Enzyme_Cent_Lib_Dir_Single_Node_Cyt.sif   Directed-Enzyme-Enzyme Network - Cytoscape Compatible
% 
% Yazdan Asgari 07/16/2016         http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input files format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check1=regexp(fileName1,'.txt');
assert(~isempty(check1),'Error in the first input: The fileName1 must contain .txt at its end')
check2=regexp(fileName2,'.xml');
assert(~isempty(check2),'Error in the second input: The fileName2 must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the Library text file and construct array of currency metabolites
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen(fileName1);
tline = fgetl(fid);
i=1;
Curr_met={};
while ischar(tline)
    Curr_met{i,1}=tline;
    tline = fgetl(fid);
    i=i+1;
end
fclose(fid);
[h,g]=size(Curr_met);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command, and sets size of the S matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName2);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the Metabolites array and check their availability in the library text file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N_curr=zeros(m,1);
for q=1:m
    for i=1:h
        if strcmp(model.metNames{q},Curr_met{i,1})==1
            N_curr(q,1)=N_curr(q,1)+1;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove metabolites which are in the input Currecny Metabolites list
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    if N_curr(q,1)~=0
        for i=1:n
            model.S(q,i)=0;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname=strrep(fileName2,'.xml','_Enzyme_Cent_Lib_Dir_Single_Node_Cyt.sif')
fout = fopen(outname, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% finds non-zero elements of the S-matrix (in order to make the algorithm faster), 
% parses through each row, and considers an edge for every unlike-signs.
% It also consider Reversibility for Enzyme-Enzyme network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num=zeros(size(model.rxns));
for j=1:m
    indices=find(model.S(j,:));
    [a,b]=size(indices);
    r=0;
    if b~=0
        r=1;
    end
    while r<b
        i=1;
        while i<(b-r+1)
            if model.S(j,indices(1,r))>0 && model.S(j,indices(1,r+i))<0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            elseif model.S(j,indices(1,r))<0 && model.S(j,indices(1,r+i))>0
                if model.rev(indices(r+i))==1 && model.rev(indices(r))==1
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r)},'reaction-product',model.rxns{indices(1,r+i)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                else
                    fprintf(fout,'%s\t%s\t%s\n',model.rxns{indices(1,r+i)},'reaction-product',model.rxns{indices(1,r)});
                    num(1,indices(1,r))=1;
                    num(1,indices(1,r+i))=1;
                end
            end
            i=i+1;
        end
        r=r+1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% considering nodes which do not contain any edges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
for k=1:n
    if num(1,k)==0
        fprintf(fout,'%s\n',model.rxns{k});
    end
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;

