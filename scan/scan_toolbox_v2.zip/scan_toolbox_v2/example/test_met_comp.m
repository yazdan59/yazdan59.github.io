function [Output] = test_met_comp(fileName1,fileName2)
tic;
model1=readCbModel(fileName1);
model2=readCbModel(fileName2);
[m,mm]=size(model1.metNames);
[n,nn]=size(model2.metNames);
outname=strcat('metabolites_in_MODEL1110130000','_not_in_MODEL1110130001')
fout = fopen(outname, 'w+');
for i=1:m
    a=0;
    for j=1:n
        if strcmp(model1.metNames{i},model2.metNames{j})==1
            a=a+1;
        end
    end
    if a==0
        fprintf(fout,'%s\t\t%s\n',model1.mets{i},model1.metNames{i});
    end
end
fclose(fout);
outname2=strcat('metabolites_in_MODEL1110130001','_not_in_MODEL1110130000')
fout2 = fopen(outname2, 'w+');
for j=1:n
    b=0;
    for i=1:m
        if strcmp(model2.metNames{j},model1.metNames{i})==1
            b=b+1;
        end
    end
    if b==0
        fprintf(fout2,'%s\t\t%s\n',model2.mets{j},model2.metNames{j});
    end
end
fclose(fout2);
toc;
