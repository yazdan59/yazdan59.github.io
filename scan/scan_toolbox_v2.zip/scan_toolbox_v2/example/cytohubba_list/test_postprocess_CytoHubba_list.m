function [Output] = test_postprocess_CytoHubba_list(Path1,Path2,N)
tic;
allcsvfiles=dir(fullfile(Path1,'*.csv'));
[a,b]=size(allcsvfiles);
sbmlfiles=dir(fullfile(Path2,'*.xml'));
[c,d]=size(sbmlfiles);
t=1;
s=1;
for r=1:a
    tic;
    D=allcsvfiles(r).name;
    if t==1
        model=readCbModel(sbmlfiles(s).name);
        sbmlfiles(s).name
        s=s+1;
    end
    if t==N
        t=0;
    end
    outname1=strrep(sbmlfiles(s-1).name,'.xml','');
    outname2=strrep(D,'.csv','.dat');
    outname3=strcat(outname1,outname2);
    fout=fopen(outname3,'w+');
 
    fid = fopen(allcsvfiles(r).name);
    fgetl(fid);
    fgetl(fid);
    M=textscan(fid,'%*d %s %*d','delimiter', ',');
    C=M{1};
    [g,h]=size(C);
    [k,n]=size(model.mets);
    [kk,nn]=size(model.rxns);
    for i=1:g
        p=0;
        if strncmp(C(i,1),'E_',2)==1
            fprintf(fout,'%s\n ',C{i});
            p=p+1;
        end
        if p==0
            for j=1:k
                Maddition=strcat('M_',model.mets{j});
                if strcmp(C(i,1),Maddition)==1
                    fprintf(fout,'%s\t%s\n ',model.mets{j},model.metNames{j});
                    p=p+1;
                    break;
                end
            end
        end
        if p==0
            for j=1:kk
                Raddition=strcat('R_',model.rxns{j});
                if strcmp(C(i,1),Raddition)==1
                    fprintf(fout,'%s\t%s\n ',model.rxns{j},model.rxnNames{j});
                    p=p+1;
                    break;
                end
            end
        end
        if p==0
            fprintf(fout,'%s\n ',C{i});
        end
    end
    fclose(fid);
    fclose(fout);
    toc;    
    t=t+1;
end
toc;
