function [Output] = test_enz_comp(fileName1,fileName2)
tic;
model1=readCbModel(fileName1);
model2=readCbModel(fileName2);
[m,mm]=size(model1.rxnNames);
[n,nn]=size(model2.rxnNames);
outname=strcat('reactions_in_MODEL1110130000','_not_in_MODEL1110130001')
fout = fopen(outname, 'w+');
for i=1:m
    a=0;
    for j=1:n
        if strcmp(model1.rxnNames{i},model2.rxnNames{j})==1
            a=a+1;
        end
    end
    if a==0
        fprintf(fout,'%s\t\t%s\n',model1.rxns{i},model1.rxnNames{i});
    end
end
fclose(fout);
outname2=strcat('reactions_in_MODEL1110130001','_not_in_MODEL1110130000')
fout2 = fopen(outname2, 'w+');
for j=1:n
    b=0;
    for i=1:m
        if strcmp(model2.rxnNames{j},model1.rxnNames{i})==1
            b=b+1;
        end
    end
    if b==0
        fprintf(fout2,'%s\t\t%s\n',model2.rxns{j},model2.rxnNames{j});
    end
end
fclose(fout2);
toc
