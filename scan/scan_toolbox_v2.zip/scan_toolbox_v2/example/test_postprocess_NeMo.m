function [Output] = test_postprocess_NeMo(fileName1,fileName2)
tic;
model=readCbModel(fileName2);
fid = fopen(fileName1);
outname=strcat('BIOMD0000000172','_glycolysis_NeMo_clusters.dat')
fout = fopen(outname, 'w+');
B={};
for i=1:10
    B{i}=fgetl(fid);
    fprintf(fout,'%s\n',B{i});
end
i=1;
A={};
line={};
while ~feof(fid)
    A{i} = fscanf(fid,'%d %f %d %d');
    line{i} = fgetl(fid);
    i=i+1;
end

M={};
for j=1:i-1
    M{1,j}=regexp(line{1,j},',','split');
end
fclose(fid);
outname2=strcat('BIOMD0000000172','_glycolysis_NeMo.dat')
fout2 = fopen(outname2, 'w+');
[h,hh]=size(model.mets);
[r,rr]=size(model.rxns);
for k=1:i-1
    k;
    [ee,e]=size(M{1,k});
    g=1;
    while g<e+1
        M{1,k}{1,g};
        if g==1
            p=0;
            if strncmp(M{1,k}{1,g},'E_',2)==1
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
                p=p+1;
            end
            if p==0
                for jj=1:r
                    Raddition=strcat('R_',model.rxns{jj});
                    if strcmp(M{1,k}{1,g},Raddition)==1
                        fprintf(fout2,'%s\t\t',model.rxnNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                for jj=1:h
                    Maddition=strcat('M_',model.mets{jj});
                    if strcmp(M{1,k}{1,g},Maddition)==1
                        fprintf(fout2,'%s\t\t',model.metNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
            end
            g=g+1;
        elseif g~=1
            p=0;
            if strncmp(M{1,k}{1,g},' E_',2)==1
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
                p=p+1;
            end
            if p==0
                for jj=1:r
                    Raddition=strcat(' R_',model.rxns{jj});
                    if strcmp(M{1,k}{1,g},Raddition)==1
                        fprintf(fout2,'%s\t\t',model.rxnNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                for jj=1:h
                    Maddition=strcat(' M_',model.mets{jj});
                    if strcmp(M{1,k}{1,g},Maddition)==1
                        fprintf(fout2,'%s\t\t',model.metNames{jj});
                        p=p+1;
                        break;
                    end
                end
            end
            if p==0
                fprintf(fout2,'%s\t\t',M{1,k}{1,g});
            end
            g=g+1;
        end
    end
    fprintf(fout2,'\n');
end
fclose(fout2);
fid2 = fopen(outname2);
y=1;
while ~feof(fid2)
    E{y}=fgetl(fid2);
    y=y+1;
end
fclose(fid2);

for i=1:i-1
    C=A{1,i};
    fprintf(fout,'%d\t%f\t%d\t%d\t%s\n',C(1),C(2),C(3),C(4),line{1,i});
    fprintf(fout,'%s\n\n',E{i});
end
fclose(fout);
toc;
