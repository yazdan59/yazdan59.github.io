function Test_SCAN()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Test_SCAN tests all functions on the SCAN-Toolbox package
% Different results will be generated at the same folder after running this function.
% This function uses Glycolysis SBML file ("BIOMD0000000172") as examples of Metabolic networks.
% It uses two Glycolysis SBML files ("BIOMD0000000172" and "BIOMD0000000042") for 'test_postprocess_CytoHubba_list' function.
% And it uses genome-scale metabolic networks from two Blattabacterium cuenoti strains (iCG230,iCG238) ("MODEL1110130000 " and "MODEL11101300001") for 'met_comp' and 'enz_comp' functions.
% NOTE: Before running this function, move to the "SCANToolbox/example/" directory.
%
% Yazdan Asgari 07/16/2016           http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CurrDir = pwd;
cd('..');
error_count = 0
j=0;
for i=1:38
    switch i
        case 1
            met_cent('example\BIOMD0000000172.xml');     j=j+1
        case 2
            met_cent_single_node('example\BIOMD0000000172.xml');     j=j+1
        case 3
            met_cent_dir('example\BIOMD0000000172.xml');     j=j+1
        case 4
            met_cent_dir_single_node('example\BIOMD0000000172.xml');     j=j+1
        case 5
            met_cent_dir_kavosh('example\BIOMD0000000172.xml');     j=j+1
        case 6
            met_cent_dir_quatexelero('example\BIOMD0000000172.xml');     j=j+1
        case 7
            enz_cent('example\BIOMD0000000172.xml');     j=j+1
        case 8
            enz_cent_single_node('example\BIOMD0000000172.xml');     j=j+1
        case 9
            enz_cent_dir('example\BIOMD0000000172.xml');     j=j+1
        case 10
            enz_cent_dir_single_node('example\BIOMD0000000172.xml');     j=j+1
        case 11
            enz_cent_dir_kavosh('example\BIOMD0000000172.xml');     j=j+1
        case 12
            enz_cent_dir_quatexelero('example\BIOMD0000000172.xml');     j=j+1
        case 13
            enz_cent_Lib('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 14
            enz_cent_Lib_single_node('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 15
            enz_cent_Lib_dir('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 16
            enz_cent_Lib_dir_single_node('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 17
            enz_cent_Lib_dir_kavosh('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 18
            enz_cent_Lib_dir_quatexelero('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 19
            enz_cent_RCM('example\BIOMD0000000172.xml');     j=j+1
        case 20
            enz_cent_RCM_single_node('example\BIOMD0000000172.xml');     j=j+1
        case 21
            enz_cent_RCM_dir('example\BIOMD0000000172.xml');     j=j+1
        case 22
            enz_cent_RCM_dir_single_node('example\BIOMD0000000172.xml');     j=j+1
        case 23
            enz_cent_RCM_dir_kavosh('example\BIOMD0000000172.xml');     j=j+1
        case 24
            enz_cent_RCM_dir_quatexelero('example\BIOMD0000000172.xml');     j=j+1
        case 25
            enz_cent_RCMLib('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 26
            enz_cent_RCMLib_single_node('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 27
            enz_cent_RCMLib_dir('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 28
            enz_cent_RCMLib_dir_single_node('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 29
            enz_cent_RCMLib_dir_kavosh('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 30
            enz_cent_RCMLib_dir_quatexelero('example\currency_metabolites.txt','example\BIOMD0000000172.xml');     j=j+1
        case 31
            cd('example'); test_postprocess_CytoHubba('glycolysis_cytohubba_mcc.csv','BIOMD0000000172.xml'); cd('..'); j=j+1
        case 32
            cd('example\cytohubba_list'); test_postprocess_CytoHubba_list('','','3'); cd('..'); cd('..'); j=j+1
        case 33
            cd('example'); test_postprocess_MCODE('glycolysis_mcode','BIOMD0000000172.xml'); cd('..'); j=j+1
        case 34
            cd('example'); test_postprocess_NeMo('glycolysis_nemo','BIOMD0000000172.xml'); cd('..'); j=j+1
        case 35
            degree_dist('example\BIOMD0000000172.xml');     j=j+1
        case 36
            met_dist('example\BIOMD0000000172.xml');     j=j+1
        case 37
            cd('example'); test_met_comp('MODEL1110130000.xml','MODEL1110130001.xml'); cd('..'); j=j+1
        case 38
            cd('example'); test_enz_comp('MODEL1110130000.xml','MODEL1110130001.xml'); cd('..'); j=j+1
        otherwise
            warning('Unexpected input. No result created. Please check the paths and files again.');
    end
end
j;
if error_count == 0
    fprintf('\nTesting completed with no errors.\n\n');
else
    fprintf('\nTesting FAILED with %i error(s).\n\n',error_count);
end
cd(CurrDir)
