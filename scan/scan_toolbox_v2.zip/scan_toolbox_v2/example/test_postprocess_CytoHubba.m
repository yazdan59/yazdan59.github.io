function [Output] = test_postprocess_CytoHubba(fileName1,fileName2)
tic;
model=readCbModel(fileName2);
outname=strcat('BIOMD0000000172','_glycolysis_cytohubba_mcc.dat')
fout = fopen(outname, 'w+');
fid = fopen(fileName1);
fgetl(fid);
fgetl(fid);
M=textscan(fid,'%*f %s %*f','delimiter', ',');
C=M{1};
[g,h]=size(C);
[k,n]=size(model.mets);
[kk,nn]=size(model.rxns);
for i=1:g
    p=0;
    if strncmp(C(i,1),'E_',2)==1
        fprintf(fout,'%s\n ',C{i});
        p=p+1;
    end
    if p==0
        for j=1:k
            Maddition=strcat('M_',model.mets{j});
            if strcmp(C(i,1),Maddition)==1
                fprintf(fout,'%s\t%s\n ',model.mets{j},model.metNames{j});
                p=p+1;
                break;
            end
        end
    end
    if p==0
        for j=1:kk
            Raddition=strcat('R_',model.rxns{j});
            if strcmp(C(i,1),Raddition)==1
                fprintf(fout,'%s\t%s\n ',model.rxns{j},model.rxnNames{j});
                p=p+1;
                break;
            end
        end
    end
    if p==0
        fprintf(fout,'%s\n ',C{i});
    end
end
fclose(fid);
fclose(fout);
toc;
