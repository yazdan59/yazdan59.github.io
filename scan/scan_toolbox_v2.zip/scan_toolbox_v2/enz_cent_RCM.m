function [Output] = enz_cent_RCM(fileName)
% Builds Binary Stoichiometric Matrix and Undirected Enzyme-Enzyme Networks Removing Currency Metabolites
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file and builds Enzyme-Enzyme Networks.
% The Remove Currency Metabolites (RCM) algorithm removes currency metabolites in the metabolic network automatically.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = enz_cent_RCM(fileName)
%
%INPUTS
% fileName                        The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Removed_Mets_RCM.dat          file contains removed metabolits from the original model
% *_Enzyme_Cent_RCM.dat           Undirected-Enzyme-Enzyme Network (comma separated Format)
% *_Enzyme_Cent_RCM_Cyt.dat       Undirected-Enzyme-Enzyme Network - Cytoscape Compatible
% 
% Yazdan Asgari 07/16/2016        http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command, and sets size of the S matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate summation of each columns (i.e. How many metabolites each enzyme correlates)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;
CB=sum(S_bin,1);
A=zeros(m,n);
B=zeros(m,1);
N3=zeros(m,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for each binary S-matrix element, subtracts its value from the column summation and put the result in the A matrix. 
% A(q) means the metabolite q connects to how many other metabolites through the enzyme i.
% for each row, sums the binary S-matrix over all columns.
% B(q) means how many enzymes the metabolite q correlates. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    for i=1:n
        if S_bin(q,i)~=0
            A(q,i)=CB(1,i)-S_bin(q,i);
        end
        B(q,1)=B(q,1)+S_bin(q,i);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assumption: Generally, every metabolite is connected to the other one through a specific enzyme.
% If a metabolite connects to more than one metabolite through an enzyme, this will be considered as a suspicious case.
% Therefore, every A(q) value equal to 3 will be marked for further analysis.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for q=1:m
    for i=1:n
        if A(q,i)==3
            N3(q,1)=N3(q,1)+1;
        end
    end
end

s=0;
for q=1:m
    if N3(q,1)~=0
        s=1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name for writing removed metabolites
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname1=strrep(fileName,'.xml','_Removed_Mets_RCM.dat')
fout1 = fopen(outname1, 'w+');
fprintf(fout1, 'Metabolite\t\tMetabolite Name\t\tMax1\t\tMax2\n');
fprintf(fout1, '----------------------------------------------\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If there is any value for N3 array, the RCM algorithm will be done.
% This algorithm will be deleted the most probable metabolite among all (i.e. the one with the maximum value of N3 and C)
% The selected metabolite will be deleted in the binary S-Matrix, and the "WHILE LOOP" repeated.
% The algorithm is ended if there is not any suspicious case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
while s==1
    C=zeros(m,1);
    max1=max(N3,[],1);
    for q=1:m
        if N3(q,1)==max1
            C(q,1)=B(q,1);
        else
            C(q,1)=0;
        end
    end
    max2=max(C,[],1);
    for q=1:m
        if ( (N3(q,1)==max1) && (C(q,1)==max2) )
            for i=1:n
                S_bin(q,i)=0;
            end
            fprintf(fout1,'%s\t\t%s\t\t%d\t\t%d\n',model.mets{q},model.metNames{q},max1,max2);
        end
    end
    
    CB=sum(S_bin,1);
    A=zeros(m,n);
    B=zeros(m,1);
    N3=zeros(m,1);
    for q=1:m
        for i=1:n
            if S_bin(q,i)~=0
                A(q,i)=CB(1,i)-S_bin(q,i);
            end
            B(q,1)=B(q,1)+S_bin(q,i);
        end
    end
    for q=1:m
        for i=1:n
            if A(q,i)==3
                N3(q,1)=N3(q,1)+1;
            end
        end
    end
    s=0;
    for q=1:m
        if N3(q,1)~=0
            s=1;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Undirected-Enzyme-Enzyme Network based on the new binary S-matrix(comma separated Format)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Aenz=S_bin'*S_bin;
outname2=strrep(fileName,'.xml','_Enzyme_Cent_RCM.dat')
dlmwrite(outname2,full(Aenz));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% re-format of Undirected-Enzyme-Enzyme Network it to a Cytoscape-compatible file.
% One could import the file using "File/Import/Network from Table(Text/MS Excel)..."
% Select "first column" as "Source Interaction" and "second column" as "Target Interaction"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m,n]=size(Aenz);
outname3=strrep(fileName,'.xml','_Enzyme_Cent_RCM_Cyt.dat')
fout2 = fopen(outname3, 'w+');
for row=1:m
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % because cell(i,j)=cell(j,i) we must delete duplicate entries by putting
    % col=row:n in the second if command. since we must ignor diagonal elements,
    % the counter will be col=row+1:n
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for col=row+1:n
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % edge are those which includes number not equal to zero
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         if Aenz(row,col)~=0
            fprintf(fout2, '%s\t%s\t%d\n',model.rxns{row},model.rxns{col},Aenz(row,col));
        end
    end
end
fclose(fout1);
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;

