function [Output] = degree_dist(fileName)
% Counts Metabolite and Enzyme degree distribution over networks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file,
% builds Undirected Metabolite-Metabolite and Enzyme-Enzyme Networks.
% Then, counts Metabolite and Enzyme degree distribution over these networks,
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = degree_cent(fileName)
%
%INPUTS
% fileName                              The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Metabolite_Cent_Degree_Dist.dat     Metabolite degree distribution (of the undirected Network)
% *_Enzyme_Cent_Degree_Dist.dat         Enzyme degree distribution (of the undirected Network)
% 
% Yazdan Asgari 07/16/2016           http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Binary Stoichiometric Matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_bin=zeros(size(model.S));
S_bin(find(model.S))=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Undirected-Metabolite-Metabolite Network
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Acomp=S_bin*S_bin';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% construction of Undirected-Enzyme-Enzyme Network
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Aenz=S_bin'*S_bin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading a Metabolic-Metabolic comma separated file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[m,n]=size(Acomp);
outname1=strrep(fileName,'.xml','_Metabolite_Cent_Degree_Dist.dat')
fout = fopen(outname1, 'w+');
fprintf(fout, 'Metabolite\t\tDegree\n');
fprintf(fout, '----------------------------------------------\n');
j=0;
for row=1:m
    i=0;
    for col=1:n
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % edge are those which includes number not equal to zero
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if Acomp(row,col)~=0
            i=i+1;
        end
    end
    fprintf(fout, '%s\t\t%d\n',model.mets{row},i);
    j=j+i;
end
fclose(fout);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading a Enzyme-Enzyme comma separated file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[g,h]=size(Aenz);
outname2=strrep(fileName,'.xml','_Enzyme_Cent_Degree_Dist.dat')
fout2 = fopen(outname2, 'w+');
fprintf(fout2, 'Reaction\t\tDegree\n');
fprintf(fout2, '----------------------------------------------\n');
jj=0;
for row=1:g
    ii=0;
    for col=1:h
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % edge are those which includes number not equal to zero
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if Aenz(row,col)~=0
            ii=ii+1;
        end
    end
    fprintf(fout2, '%s\t\t%d\n',model.rxns{row},ii);
    jj=jj+ii;
end
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;
