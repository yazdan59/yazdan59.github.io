function [Output] = met_cent_dir_kavosh(fileName)
% Builds Directed Enzyme-Enzyme Networks which could be used as an input for Kavosh Algorithm.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function reads a Metabolic Network SBML file,
% and builds Directed Metabolite-Metabolite Networks which is compatible with Kavosh Algorithm.
% The Kavosh is one of the best motif finding algorithms. Its Cytoscape plugins is also called CytoKavosh.
% http://lbb.ut.ac.ir/Download/LBBsoft/Kavosh/  &   http://www.ncbi.nlm.nih.gov/pubmed/19799800
% http://lbb.ut.ac.ir/Download/LBBsoft/CytoKavosh/CytoKavosh-Manual/cytoKavoshTutorial.html
% So, one could easily use this algorithm in order to find motifs in different sizes for the metabolic network.
% Note: COBRA Toolbox must be installed in MATLAB before running this function
%
% [Output] = met_cent_dir_kavosh(fileName)
%
%INPUTS
% fileName                             The metabolic Network in the SBML format
% 
%OUTPUTS
% *_Metabolite_Cent_Dir_Index.dat      Matrix Indeces of Metabolite-Metabolite Connections 
% *_Metabolite_Cent_Dir_Kavosh.dat     Directed-Metabolite-Metabolite Network - Kavosh Compatible
% 
% Yazdan Asgari 07/16/2016      http://yazdan59.ir/scan
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check validity of input file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
check=regexp(fileName,'.xml');
assert(~isempty(check),'The SBML fileName must contain .xml at its end')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the Library text file and construct array of carriors of electrons , protons and energy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen('carr_mets.txt');
tline = fgetl(fid);
i=1;
Curr_met={};
while ischar(tline)
    Curr_met{i,1}=tline;
    tline = fgetl(fid);
    i=i+1;
end
fclose(fid);
[h,g]=size(Curr_met);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the SBML file using COBRA Toolbox Command
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model=readCbModel(fileName);
[m,n]=size(model.S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname=strrep(fileName,'.xml','_Metabolite_Cent_Dir_Index.dat')
fout = fopen(outname, 'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% finds non-zero elements of the S-matrix (in order to make the algorithm faster), 
% parses through each column, and considers an edge for every unlike-signs.
% It also consider Reversibility for Enzyme-Enzyme network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num=zeros(size(model.mets));
for j=1:n
    indices=find(model.S(:,j));
    [a,b]=size(indices);
    r=0;
    if a~=0
        r=1;
    end
    while r<a
        i=1;
        while i<(a-r+1)
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % reading every metabolite and check its availability in the carriors metabolites text file
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            N=0;
            for k=1:h
                if strcmp(model.metNames{indices(r,1)},Curr_met{k,1})==1
                    N=1;
                    break
                elseif strcmp(model.metNames{indices(r+i,1)},Curr_met{k,1})==1
                    N=1;
                    break
                end
            end
            if model.S(indices(r,1),j)<0 && model.S(indices(r+i,1),j)>0
                if model.rev(j)==1 && N==0
                    fprintf(fout,'%d\t%d\n',indices(r,1),indices(r+i,1));
                    fprintf(fout,'%d\t%d\n',indices(r+i,1),indices(r,1));
                else
                    fprintf(fout,'%d\t%d\n',indices(r,1),indices(r+i,1));
                end
            elseif model.S(indices(r,1),j)>0 && model.S(indices(r+i,1),j)<0
                if model.rev(j)==1 && N==0
                    fprintf(fout,'%d\t%d\n',indices(r+i,1),indices(r,1));
                    fprintf(fout,'%d\t%d\n',indices(r,1),indices(r+i,1));
                else
                    fprintf(fout,'%d\t%d\n',indices(r+i,1),indices(r,1));
                end
            end
            i=i+1;
        end
        r=r+1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% building the output file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outname2=strrep(fileName,'.xml','_Metabolite_Cent_Dir_Kavosh.dat')    
fout2=fopen(outname2,'w+');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reading the constructed Metabolic-Metabolic network file and re-format it to a Kavosh-compatible file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen(outname);
C=fscanf(fid,'%d');
i=1;
while isinteger(fid)
    C(i)=fscanf(fid,'%d',C);
    i=i+1;
end
g=size(C);
A=size(unique(C));
if g~=0
    n=1;
else
    disp('Error in reading the file, No Edge detected')
end
k=1;
j=2;
last=g/2;
fprintf(fout2,'%d\n',A(1,1));   % total number of uniques nodes in the network (needed for Kavosh Algorithm)
for i=1:last
    fprintf(fout2,'%d\t%d\n ',C(k),C(j));
    k=k+2;
    j=j+2;
end
fclose(fid);
fclose(fout2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of time evaluation of program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc;

